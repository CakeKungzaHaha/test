import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, Database, ShieldAlert, CheckCircle2, XCircle, TrendingUp, FileText, RefreshCcw, Info } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, LineChart, Line, Legend } from 'recharts';
import './styles.css';

const defaultSuggestions = [
  { symbol: 'AAPL', name: 'Apple Inc.', exchange: 'NASDAQ' },
  { symbol: 'MSFT', name: 'Microsoft Corporation', exchange: 'NASDAQ' },
  { symbol: 'NVDA', name: 'NVIDIA Corporation', exchange: 'NASDAQ' },
  { symbol: 'AMZN', name: 'Amazon.com, Inc.', exchange: 'NASDAQ' },
  { symbol: 'GOOGL', name: 'Alphabet Inc. Class A', exchange: 'NASDAQ' },
  { symbol: 'META', name: 'Meta Platforms, Inc.', exchange: 'NASDAQ' },
  { symbol: 'TSLA', name: 'Tesla, Inc.', exchange: 'NASDAQ' }
];

function fmtPct(v) {
  return Number.isFinite(v) ? `${(v * 100).toFixed(2)}%` : '-';
}
function fmtNum(v, d = 2) {
  return Number.isFinite(v) ? Number(v).toFixed(d) : '-';
}
function fmtMoney(v) {
  if (!Number.isFinite(v)) return '-';
  const abs = Math.abs(v);
  if (abs >= 1e12) return `$${(v / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(v / 1e6).toFixed(2)}M`;
  return `$${v.toFixed(0)}`;
}
function fmtDate(v) {
  return v || '-';
}

function useDebounced(value, delay = 250) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return debounced;
}

function App() {
  const [query, setQuery] = useState('AAPL');
  const [suggestions, setSuggestions] = useState(defaultSuggestions);
  const [selected, setSelected] = useState(defaultSuggestions[0]);
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loadingSearch, setLoadingSearch] = useState(false);
  const [loadingAnalyze, setLoadingAnalyze] = useState(false);
  const [error, setError] = useState('');
  const debounced = useDebounced(query);

  useEffect(() => {
    let cancelled = false;
    async function search() {
      setLoadingSearch(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(debounced)}`);
        const json = await res.json();
        if (!cancelled && json.results) setSuggestions(json.results);
      } catch (e) {
        if (!cancelled) setSuggestions(defaultSuggestions.filter(x => x.symbol.toLowerCase().startsWith(debounced.toLowerCase())));
      } finally {
        if (!cancelled) setLoadingSearch(false);
      }
    }
    search();
    return () => { cancelled = true; };
  }, [debounced]);

  async function analyze(symbol = selected?.symbol || query) {
    const clean = String(symbol || '').trim().toUpperCase();
    if (!clean) return;
    setLoadingAnalyze(true);
    setError('');
    try {
      const res = await fetch(`/api/analyze/${encodeURIComponent(clean)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || 'analyze failed');
      setData(json);
      setSelected(json.company);
      setQuery(json.symbol);
      setActiveTab('overview');
    } catch (e) {
      setError(e.message || String(e));
    } finally {
      setLoadingAnalyze(false);
    }
  }

  useEffect(() => { analyze('AAPL'); }, []);

  const priceChart = useMemo(() => (data?.prices || []).slice(-260), [data]);
  const financialRows = useMemo(() => {
    const rows = data?.financials?.rows || [];
    return rows.slice(0, 16).reverse().map(r => ({
      label: `${r.fy || ''} ${r.fp || ''}`,
      end: r.end,
      revenue: Number.isFinite(r.revenue) ? r.revenue / 1e9 : null,
      netIncome: Number.isFinite(r.netIncome) ? r.netIncome / 1e9 : null,
      fcf: Number.isFinite(r.freeCashFlow) ? r.freeCashFlow / 1e9 : null,
      dividendsPaid: Number.isFinite(r.dividendsPaid) ? r.dividendsPaid / 1e9 : null,
      debtRatio: Number.isFinite(r.assets) && Number.isFinite(r.liabilities) ? r.liabilities / r.assets : null
    }));
  }, [data]);

  return (
    <div className="page">
      <header className="hero">
        <div className="badge"><Database size={16}/> SEC EDGAR + Stooq/Yahoo • No API Key • Econometrics Pro</div>
        <h1>US Stock Econometrics Dashboard</h1>
        <p>ค้นหาหุ้นสหรัฐ ดึงราคาฟรีจาก Stooq และมี Yahoo fallback ถ้า Stooq ไม่มีข้อมูล พร้อมงบการเงินจริงจาก SEC EDGAR แล้ววิเคราะห์ความเสี่ยงระยะสั้น/ยาวด้วย econometrics รวมถึงความเสี่ยงปันผลสูง, yield trap, rolling beta, residual risk และ multi-factor regression</p>
      </header>

      <section className="searchBox card">
        <div className="searchGrid">
          <div className="inputWrap">
            <label>ค้นหา ticker หรือชื่อบริษัท</label>
            <div className="inputLine">
              <Search size={18}/>
              <input value={query} onChange={e => setQuery(e.target.value)} placeholder="พิมพ์ a, apple, nvda, microsoft" onKeyDown={e => { if (e.key === 'Enter') analyze(suggestions[0]?.symbol || query); }} />
            </div>
          </div>
          <button className="primary" onClick={() => analyze(suggestions[0]?.symbol || query)} disabled={loadingAnalyze}>
            {loadingAnalyze ? 'กำลังวิเคราะห์...' : 'วิเคราะห์'}
          </button>
        </div>

        <div className="suggestions">
          {loadingSearch && <span className="muted">กำลังค้นหา...</span>}
          {!loadingSearch && suggestions.slice(0, 12).map(item => (
            <button key={`${item.symbol}-${item.cik}`} className={`suggestion ${selected?.symbol === item.symbol ? 'selected' : ''}`} onClick={() => { setSelected(item); setQuery(item.symbol); analyze(item.symbol); }}>
              <b>{item.symbol}</b>
              <span>{item.name}</span>
              <small>{item.exchange || '-'}</small>
            </button>
          ))}
        </div>
        {error && <div className="error"><ShieldAlert size={16}/> {error}</div>}
      </section>

      {data && (
        <>
          <section className="summaryGrid">
            <Metric title="ราคาล่าสุด" value={fmtMoney(data.prices?.at(-1)?.close)} sub={data.validation?.latestPriceDate || '-'} icon={<TrendingUp size={18}/>} />
            <Metric title="Volatility ต่อปี" value={fmtPct(data.metrics.annualVol)} sub="log return × √252" />
            <Metric title="Beta เทียบ SPY" value={fmtNum(data.metrics.beta)} sub={`R² ${fmtNum(data.metrics.r2)}`} />
            <Metric title="VaR 95% รายวัน" value={fmtPct(data.metrics.var95)} sub="ผลตอบแทนด้านล่าง 5%" />
            <Metric title="Drawdown สูงสุด" value={fmtPct(data.metrics.maxDrawdown)} sub="จากราคาปิด Stooq" />
            <Metric title="Revenue TTM" value={fmtMoney(data.metrics.revenue)} sub={data.metrics.source || 'TTM'} />
            <Metric title="Net Margin" value={fmtPct(data.metrics.netMargin)} sub="Net Income / Revenue" />
            <Metric title="FCF TTM" value={fmtMoney(data.metrics.freeCashFlow)} sub="Operating CF - CapEx" />
            <Metric title="Dividend Yield" value={fmtPct(data.metrics.dividendYield)} sub={`TTM/share ${fmtNum(data.metrics.ttmDividendPerShare, 4)}`} />
            <Metric title="Payout / FCF" value={fmtPct(data.metrics.dividendPayoutFcf)} sub="Dividends Paid / FCF" />
          </section>

          <nav className="tabs">
            {[
              ['overview', 'ภาพรวม'],
              ['source', 'ข้อมูลที่ดึงมา'],
              ['financials', 'งบการเงิน'],
              ['risk', 'วิเคราะห์ความเสี่ยง'],
              ['econometrics', 'Econometrics']
            ].map(([id, label]) => <button key={id} onClick={() => setActiveTab(id)} className={activeTab === id ? 'active' : ''}>{label}</button>)}
          </nav>

          {activeTab === 'overview' && <Overview data={data} priceChart={priceChart} financialRows={financialRows} />}
          {activeTab === 'source' && <SourceTab data={data} />}
          {activeTab === 'financials' && <FinancialsTab data={data} financialRows={financialRows} />}
          {activeTab === 'risk' && <RiskTab data={data} />}
          {activeTab === 'econometrics' && <EconometricsTab data={data} />}
        </>
      )}
    </div>
  );
}

function Metric({ title, value, sub, icon }) {
  return <div className="metric card"><div className="metricTop"><span>{title}</span>{icon}</div><strong>{value}</strong><small>{sub}</small></div>;
}

function Overview({ data, priceChart, financialRows }) {
  return (
    <section className="grid2">
      <div className="card panel wide">
        <h2>กราฟราคาหุ้น {data.symbol}</h2>
        <p className="muted">ใช้ราคาปิดรายวันจาก Stooq จำนวน {data.metrics.priceRows} แถว</p>
        <div className="chart">
          {priceChart.length ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={priceChart}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" minTickGap={38}/>
                <YAxis domain={["auto", "auto"]}/>
                <Tooltip />
                <Area type="monotone" dataKey="close" name="Close" fillOpacity={0.18} strokeWidth={2}/>
              </AreaChart>
            </ResponsiveContainer>
          ) : <NoData text="ไม่มีข้อมูลราคาสำหรับ ticker นี้จากแหล่งฟรีที่ลองดึง" />}
        </div>
      </div>
      <div className="card panel">
        <h2>สรุปบริษัท</h2>
        <div className="infoList">
          <Row k="Ticker" v={data.symbol}/>
          <Row k="ชื่อ" v={data.company.name}/>
          <Row k="ตลาด" v={data.company.exchange}/>
          <Row k="CIK" v={data.company.cik}/>
          <Row k="ดึงข้อมูลเมื่อ" v={new Date(data.fetchedAt).toLocaleString()}/>
        </div>
        <div className="riskBoxes">
          <div><span>ระยะสั้น</span><b>{data.risk.short.label}</b><small>{data.risk.short.score}/{data.risk.short.maxScore} คะแนน</small></div>
          <div><span>ระยะยาว</span><b>{data.risk.long.label}</b><small>{data.risk.long.score}/{data.risk.long.maxScore} คะแนน</small></div>
        </div>
      </div>
      <div className="card panel wide">
        <h2>งบการเงินล่าสุด</h2>
        <p className="muted">หน่วยในกราฟ: พันล้านดอลลาร์ จับตาม fiscal period จาก SEC</p>
        <div className="chart">
          {financialRows.some(r => Number.isFinite(r.revenue) || Number.isFinite(r.netIncome) || Number.isFinite(r.fcf)) ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={financialRows}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="revenue" name="Revenue" />
                <Bar dataKey="netIncome" name="Net Income" />
                <Bar dataKey="fcf" name="FCF" />
                <Bar dataKey="dividendsPaid" name="Dividends Paid" />
              </BarChart>
            </ResponsiveContainer>
          ) : <NoData text="ข้อมูล Revenue / Net Income / FCF ไม่พอสำหรับกราฟนี้" />}
        </div>
      </div>
      <div className="card panel">
        <h2>Debt Ratio Trend</h2>
        <p className="muted">Liabilities / Assets</p>
        <div className="chart smallChart">
          {financialRows.some(r => Number.isFinite(r.debtRatio)) ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={financialRows}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" />
                <YAxis tickFormatter={v => `${(v * 100).toFixed(0)}%`} />
                <Tooltip formatter={v => fmtPct(Number(v))} />
                <Line type="monotone" dataKey="debtRatio" name="Debt Ratio" strokeWidth={2} dot />
              </LineChart>
            </ResponsiveContainer>
          ) : <NoData text="ข้อมูล Assets / Liabilities ไม่พอสำหรับ Debt Ratio Trend" />}
        </div>
      </div>
    </section>
  );
}

function SourceTab({ data }) {
  return (
    <section className="card panel">
      <h2><Info size={20}/> ข้อมูลที่ดึงมาและความถูกต้องเบื้องต้น</h2>
      <p className="muted">หน้านี้ช่วยเช็คว่าเว็บดึงข้อมูลอะไรมา จากแหล่งไหน และพอสำหรับการคำนวณหรือไม่</p>
      <div className="sourceGrid">
        {Object.entries(data.providers).map(([k, v]) => <div key={k} className="sourceCard"><span>{k}</span><b>{v}</b></div>)}
      </div>
      <h3>ลำดับการลองดึงราคาหุ้น</h3>
      <div className="checks compact">
        {(data.priceFetchAttempts || []).map((a, i) => <div key={i} className="checkRow">{a.ok ? <CheckCircle2/> : <XCircle/>}<div><b>{a.provider}</b><span>{a.rows} แถว {a.error ? `• ${a.error}` : ''}</span></div></div>)}
      </div>
      <h3>ลำดับการลองดึง benchmark SPY</h3>
      <div className="checks compact">
        {(data.marketFetchAttempts || []).map((a, i) => <div key={i} className="checkRow">{a.ok ? <CheckCircle2/> : <XCircle/>}<div><b>{a.provider}</b><span>{a.rows} แถว {a.error ? `• ${a.error}` : ''}</span></div></div>)}
      </div>
      <h3>ลำดับการลองดึง factor สำหรับ Econometrics</h3>
      <div className="checks compact">
        {(data.factorFetchAttempts || []).map((a, i) => <div key={i} className="checkRow">{a.ok ? <CheckCircle2/> : <XCircle/>}<div><b>{a.symbol} • {a.provider}</b><span>{a.rows} แถว</span></div></div>)}
      </div>
      <h3>ลำดับการลองดึงข้อมูลปันผล</h3>
      <div className="checks compact">
        {(data.dividendFetchAttempts || []).map((a, i) => <div key={i} className="checkRow">{a.ok ? <CheckCircle2/> : <XCircle/>}<div><b>{a.provider}</b><span>{a.rows} รายการ {a.error ? `• ${a.error}` : ""}</span></div></div>)}
      </div>
      <h3>ผลตรวจข้อมูล</h3>
      <div className="checks">
        {data.validation.checks.map((c, i) => <div key={i} className="checkRow">{c.ok ? <CheckCircle2/> : <XCircle/>}<div><b>{c.name}</b><span>{c.detail}</span></div></div>)}
      </div>
      <h3>Concept ที่ใช้จาก SEC XBRL</h3>
      <div className="tableWrap"><table><tbody>{Object.entries(data.financials.conceptsUsed).map(([k, v]) => <tr key={k}><td>{k}</td><td>{v || '-'}</td></tr>)}</tbody></table></div>
      <h3>หมายเหตุจากระบบแปลงงบ</h3>
      <ul className="noteList">{(data.financials.notes || []).map((x, i) => <li key={i}>{x}</li>)}</ul>
      <h3>ราคาล่าสุด 10 แถว</h3>
      <PriceTable rows={(data.prices || []).slice(-10).reverse()} />
    </section>
  );
}

function FinancialsTab({ data, financialRows }) {
  return (
    <section className="grid2">
      <div className="card panel wide">
        <h2><FileText size={20}/> ตารางงบจาก SEC</h2>
        <p className="muted">เว็บรวม concept สำคัญตาม fiscal period เดียวกัน ถ้าช่องว่างแปลว่า SEC ไม่มี concept นั้นใน period นั้น หรือบริษัทใช้ taxonomy ต่างกัน</p>
        <div className="tableWrap"><table><thead><tr><th>Period</th><th>End</th><th>Days</th><th>Frame</th><th>Revenue</th><th>Net Income</th><th>Assets</th><th>Liabilities</th><th>Equity</th><th>OCF</th><th>CapEx</th><th>Dividends Paid</th><th>FCF</th></tr></thead><tbody>{(data.financials.rows || []).slice(0, 24).map((r, i) => <tr key={i}><td>{r.fy} {r.fp}</td><td>{r.end}</td><td>{r.durationDays || '-'}</td><td>{r.frame || '-'}</td><td>{fmtMoney(r.revenue)}</td><td>{fmtMoney(r.netIncome)}</td><td>{fmtMoney(r.assets)}</td><td>{fmtMoney(r.liabilities)}</td><td>{fmtMoney(r.equity)}</td><td>{fmtMoney(r.operatingCashFlow)}</td><td>{fmtMoney(r.capex)}</td><td>{fmtMoney(r.dividendsPaid)}</td><td>{fmtMoney(r.freeCashFlow)}</td></tr>)}</tbody></table></div>
      </div>
      <div className="card panel">
        <h2>TTM / Ratio</h2>
        <div className="infoList">
          <Row k="TTM Source" v={data.metrics.source}/>
          <Row k="Revenue TTM" v={fmtMoney(data.metrics.revenue)}/>
          <Row k="Net Income TTM" v={fmtMoney(data.metrics.netIncome)}/>
          <Row k="Operating CF TTM" v={fmtMoney(data.metrics.operatingCashFlow)}/>
          <Row k="CapEx TTM" v={fmtMoney(data.metrics.capex)}/>
          <Row k="FCF TTM" v={fmtMoney(data.metrics.freeCashFlow)}/>
          <Row k="Dividends Paid TTM" v={fmtMoney(data.metrics.dividendsPaid)}/>
          <Row k="Dividend / Share TTM" v={fmtNum(data.metrics.ttmDividendPerShare, 4)}/>
          <Row k="Dividend Yield" v={fmtPct(data.metrics.dividendYield)}/>
          <Row k="Net Margin" v={fmtPct(data.metrics.netMargin)}/>
          <Row k="ROE" v={fmtPct(data.metrics.roe)}/>
          <Row k="Debt Ratio" v={fmtPct(data.metrics.debtRatio)}/>
          <Row k="FCF Margin" v={fmtPct(data.metrics.fcfMargin)}/>
          <Row k="Payout / Net Income" v={fmtPct(data.metrics.dividendPayoutNetIncome)}/>
          <Row k="Payout / FCF" v={fmtPct(data.metrics.dividendPayoutFcf)}/>
        </div>
      </div>
    </section>
  );
}

function RiskTab({ data }) {
  return (
    <section className="grid2">
      <RiskCard title="ความเสี่ยงระยะสั้น" risk={data.risk.short} />
      <RiskCard title="ความเสี่ยงระยะยาว" risk={data.risk.long} />
      <div className="card panel wide">
        <h2>รายละเอียด Econometrics</h2>
        <div className="infoList columns">
          <Row k="Annualized Return" v={fmtPct(data.metrics.annualReturn)}/>
          <Row k="Annualized Volatility" v={fmtPct(data.metrics.annualVol)}/>
          <Row k="VaR 95% Daily" v={fmtPct(data.metrics.var95)}/>
          <Row k="Max Drawdown" v={fmtPct(data.metrics.maxDrawdown)}/>
          <Row k="OLS Alpha" v={fmtPct(data.metrics.alpha)}/>
          <Row k="OLS Beta" v={fmtNum(data.metrics.beta)}/>
          <Row k="R²" v={fmtNum(data.metrics.r2)}/>
          <Row k="Matched Benchmark Rows" v={data.metrics.matchedBenchmarkRows}/>
          <Row k="Regression Observations" v={data.metrics.regressionObservations}/>
          <Row k="1Y Price Return" v={fmtPct(data.metrics.oneYearReturn)}/>
          <Row k="Dividend Yield" v={fmtPct(data.metrics.dividendYield)}/>
          <Row k="Payout / FCF" v={fmtPct(data.metrics.dividendPayoutFcf)}/>
        </div>
        <p className="note">Beta คำนวณจากวันที่ราคาหุ้นและ SPY ตรงกันเท่านั้น เพื่อป้องกันการเอาข้อมูลคนละวันมาเทียบกัน</p>
      </div>
    </section>
  );
}


function EconometricsTab({ data }) {
  const econ = data.econometrics || {};
  const multi = econ.multiFactor || {};
  const coeffs = multi.coefficients || [];
  const rollingRows = econ.rollingBeta || [];
  const fittedRows = multi.fitted || [];
  return (
    <section className="grid2">
      <div className="card panel wide">
        <h2>Econometrics Pro: โมเดลอธิบายการแกว่งของหุ้น</h2>
        <p className="muted">ใช้ log return รายวัน จับวันที่ตรงกัน แล้วรัน OLS ทั้งแบบ single-factor และ multi-factor เพื่อแยกความเสี่ยงตลาดออกจากความเสี่ยงเฉพาะตัว</p>
        <div className="infoList columns">
          <Row k="Single-factor Beta vs SPY" v={fmtNum(econ.singleFactor?.beta)} />
          <Row k="Single-factor R²" v={fmtNum(econ.singleFactor?.r2)} />
          <Row k="Multi-factor R²" v={fmtNum(multi.r2)} />
          <Row k="Adjusted R²" v={fmtNum(multi.adjR2)} />
          <Row k="Residual Vol ต่อปี" v={fmtPct(multi.residualVolAnnual)} />
          <Row k="Observations" v={multi.observations ?? '-'} />
          <Row k="Model Confidence" v={`${econ.modelConfidence?.label || '-'} (${econ.modelConfidence?.score ?? '-'}/${econ.modelConfidence?.maxScore ?? '-'})`} />
          <Row k="Factors" v={(multi.factors || []).join(', ') || '-'} />
        </div>
        <div className="noteList">
          {(econ.interpretation || []).map((x, i) => <li key={i}>{x}</li>)}
          {(econ.modelConfidence?.reasons || []).map((x, i) => <li key={`c-${i}`}>Confidence: {x}</li>)}
        </div>
      </div>

      <div className="card panel wide">
        <h2>Multi-factor Regression Coefficients</h2>
        <p className="muted">สมการ: stock return = alpha + b1×SPY + b2×QQQ + b3×IWM + b4×TLT + b5×USO + error</p>
        {coeffs.length ? (
          <div className="tableWrap"><table><thead><tr><th>Factor</th><th>Coefficient</th><th>Std. Error</th><th>t-stat</th><th>แปลผลเร็ว</th></tr></thead><tbody>{coeffs.map(c => <tr key={c.name}><td>{c.name}</td><td>{fmtNum(c.coefficient, 4)}</td><td>{fmtNum(c.stdError, 4)}</td><td>{fmtNum(c.tStat, 2)}</td><td>{c.name === 'Alpha' ? 'ผลตอบแทนส่วนเกินเฉลี่ยหลังคุม factor' : Math.abs(c.coefficient) > 1 ? 'ไวต่อ factor นี้มาก' : Math.abs(c.coefficient) > 0.3 ? 'สัมพันธ์ปานกลาง' : 'สัมพันธ์ต่ำ'}</td></tr>)}</tbody></table></div>
        ) : <NoData text={multi.reason || 'ข้อมูลไม่พอสำหรับ multi-factor regression'} />}
      </div>

      <div className="card panel wide">
        <h2>Rolling Beta</h2>
        <p className="muted">Beta ที่เปลี่ยนตามเวลา ช่วยดูว่าหุ้นเริ่มไวต่อตลาดมากขึ้นหรือน้อยลง</p>
        <div className="chart">
          {rollingRows.some(r => Number.isFinite(r.beta30) || Number.isFinite(r.beta90) || Number.isFinite(r.beta180)) ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={rollingRows}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" minTickGap={38}/>
                <YAxis domain={["auto", "auto"]}/>
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="beta30" name="Beta 30D" dot={false} strokeWidth={2}/>
                <Line type="monotone" dataKey="beta90" name="Beta 90D" dot={false} strokeWidth={2}/>
                <Line type="monotone" dataKey="beta180" name="Beta 180D" dot={false} strokeWidth={2}/>
              </LineChart>
            </ResponsiveContainer>
          ) : <NoData text="ข้อมูลราคาที่ match กับ SPY ยังไม่พอสำหรับ rolling beta" />}
        </div>
      </div>

      <div className="card panel wide">
        <h2>Actual vs Fitted Return และ Residual</h2>
        <p className="muted">ถ้า residual แกว่งแรง แปลว่ามีความเสี่ยงเฉพาะตัวที่ factor ตลาดอธิบายไม่ได้</p>
        <div className="chart">
          {fittedRows.length ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={fittedRows}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" minTickGap={38}/>
                <YAxis tickFormatter={v => `${(v * 100).toFixed(1)}%`} />
                <Tooltip formatter={v => fmtPct(Number(v))}/>
                <Legend />
                <Line type="monotone" dataKey="actual" name="Actual return" dot={false} strokeWidth={1}/>
                <Line type="monotone" dataKey="fitted" name="Fitted return" dot={false} strokeWidth={2}/>
                <Line type="monotone" dataKey="residual" name="Residual" dot={false} strokeWidth={1}/>
              </LineChart>
            </ResponsiveContainer>
          ) : <NoData text="ยังไม่มี fitted/residual series เพราะ multi-factor model ไม่พร้อม" />}
        </div>
      </div>

      <div className="card panel wide">
        <h2>Factor Coverage</h2>
        <p className="muted">จำนวนแถวราคาของ factor proxy ที่ดึงได้จากแหล่งฟรี</p>
        <div className="sourceGrid">
          {Object.entries(econ.factorCoverage || {}).map(([k, v]) => <div key={k} className="sourceCard"><span>{k}</span><b>{v.rows} แถว</b></div>)}
        </div>
        <p className="note">ข้อจำกัด: โมเดลนี้เป็นเชิงสถิติจากข้อมูลราคาในอดีต ไม่ใช่คำทำนายแน่นอน และ factor proxy เช่น QQQ/TLT/USO เป็นตัวแทนเชิงประมาณ ไม่ใช่สาเหตุแท้ทั้งหมดของราคาหุ้น</p>
      </div>
    </section>
  );
}

function RiskCard({ title, risk }) {
  return <div className="card panel"><h2>{title}</h2><div className="bigRisk"><span>{risk.label}</span><b>{risk.score}/{risk.maxScore}</b></div>{risk.parts.map((p, i) => <div className="riskPart" key={i}><div><b>{p.name}</b><span>{p.reason} {Number.isFinite(p.value) ? `• ค่า ${Math.abs(p.value) < 2 ? fmtPct(p.value) : fmtNum(p.value)}` : ''}</span></div><strong>{p.points}</strong></div>)}</div>;
}


function NoData({ text }) {
  return <div className="noData"><XCircle size={22}/><b>ข้อมูลไม่พอ</b><span>{text}</span></div>;
}

function PriceTable({ rows }) {
  return <div className="tableWrap"><table><thead><tr><th>Date</th><th>Open</th><th>High</th><th>Low</th><th>Close</th><th>Volume</th></tr></thead><tbody>{rows.map(r => <tr key={r.date}><td>{r.date}</td><td>{fmtNum(r.open)}</td><td>{fmtNum(r.high)}</td><td>{fmtNum(r.low)}</td><td>{fmtNum(r.close)}</td><td>{Number.isFinite(r.volume) ? r.volume.toLocaleString() : '-'}</td></tr>)}</tbody></table></div>;
}

function Row({ k, v }) { return <div className="row"><span>{k}</span><b>{v ?? '-'}</b></div>; }

createRoot(document.getElementById('root')).render(<App />);
