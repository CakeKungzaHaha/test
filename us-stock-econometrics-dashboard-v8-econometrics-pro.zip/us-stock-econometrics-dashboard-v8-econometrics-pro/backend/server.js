import express from 'express';
import cors from 'cors';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 5000);
const CONTACT_EMAIL = process.env.SEC_CONTACT_EMAIL || 'example@example.com';

app.use(cors());
app.use(express.json());

const secClient = axios.create({
  timeout: 20000,
  headers: {
    'User-Agent': `USStockEconometricsDashboard/8.0 contact:${CONTACT_EMAIL}`,
    'Accept-Encoding': 'gzip, deflate',
    Accept: 'application/json,text/plain,*/*'
  }
});

const normalClient = axios.create({ timeout: 20000 });

let tickerCache = null;
let tickerCacheAt = 0;
const CACHE_MS = 1000 * 60 * 60 * 12;

const FALLBACK_TICKERS = [
  { symbol: 'AAPL', name: 'Apple Inc.', cik: '0000320193', exchange: 'NASDAQ' },
  { symbol: 'MSFT', name: 'Microsoft Corporation', cik: '0000789019', exchange: 'NASDAQ' },
  { symbol: 'NVDA', name: 'NVIDIA Corporation', cik: '0001045810', exchange: 'NASDAQ' },
  { symbol: 'AMZN', name: 'Amazon.com, Inc.', cik: '0001018724', exchange: 'NASDAQ' },
  { symbol: 'GOOGL', name: 'Alphabet Inc. Class A', cik: '0001652044', exchange: 'NASDAQ' },
  { symbol: 'GOOG', name: 'Alphabet Inc. Class C', cik: '0001652044', exchange: 'NASDAQ' },
  { symbol: 'META', name: 'Meta Platforms, Inc.', cik: '0001326801', exchange: 'NASDAQ' },
  { symbol: 'TSLA', name: 'Tesla, Inc.', cik: '0001318605', exchange: 'NASDAQ' },
  { symbol: 'AMD', name: 'Advanced Micro Devices, Inc.', cik: '0000002488', exchange: 'NASDAQ' },
  { symbol: 'INTC', name: 'Intel Corporation', cik: '0000050863', exchange: 'NASDAQ' },
  { symbol: 'AVGO', name: 'Broadcom Inc.', cik: '0001730168', exchange: 'NASDAQ' },
  { symbol: 'ADBE', name: 'Adobe Inc.', cik: '0000796343', exchange: 'NASDAQ' },
  { symbol: 'NFLX', name: 'Netflix, Inc.', cik: '0001065280', exchange: 'NASDAQ' },
  { symbol: 'JPM', name: 'JPMorgan Chase & Co.', cik: '0000019617', exchange: 'NYSE' },
  { symbol: 'V', name: 'Visa Inc.', cik: '0001403161', exchange: 'NYSE' },
  { symbol: 'WMT', name: 'Walmart Inc.', cik: '0000104169', exchange: 'NYSE' },
  { symbol: 'T', name: 'AT&T Inc.', cik: '0000732717', exchange: 'NYSE' },
  { symbol: 'VZ', name: 'Verizon Communications Inc.', cik: '0000732712', exchange: 'NYSE' },
  { symbol: 'MO', name: 'Altria Group, Inc.', cik: '0000764180', exchange: 'NYSE' },
  { symbol: 'O', name: 'Realty Income Corporation', cik: '0000726728', exchange: 'NYSE' },
  { symbol: 'XOM', name: 'Exxon Mobil Corporation', cik: '0000034088', exchange: 'NYSE' },
  { symbol: 'CVX', name: 'Chevron Corporation', cik: '0000093410', exchange: 'NYSE' },
  { symbol: 'KO', name: 'The Coca-Cola Company', cik: '0000021344', exchange: 'NYSE' },
  { symbol: 'PEP', name: 'PepsiCo, Inc.', cik: '0000077476', exchange: 'NASDAQ' },
  { symbol: 'IBM', name: 'International Business Machines Corporation', cik: '0000051143', exchange: 'NYSE' },
  { symbol: 'MMM', name: '3M Company', cik: '0000066740', exchange: 'NYSE' },
  { symbol: 'WBA', name: 'Walgreens Boots Alliance, Inc.', cik: '0001618921', exchange: 'NASDAQ' }
];

function padCik(cik) {
  return String(cik).replace(/^0+/, '').padStart(10, '0');
}

function n(v) {
  const x = Number(v);
  return Number.isFinite(x) ? x : null;
}

function mean(arr) {
  const xs = arr.filter(Number.isFinite);
  if (!xs.length) return null;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function stdev(arr) {
  const xs = arr.filter(Number.isFinite);
  if (xs.length < 2) return null;
  const m = mean(xs);
  return Math.sqrt(xs.reduce((s, x) => s + (x - m) ** 2, 0) / (xs.length - 1));
}

function percentile(arr, q) {
  const xs = arr.filter(Number.isFinite).sort((a, b) => a - b);
  if (!xs.length) return null;
  const pos = (xs.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  return xs[base + 1] !== undefined ? xs[base] + rest * (xs[base + 1] - xs[base]) : xs[base];
}

function ols(x, y) {
  const pairs = [];
  for (let i = 0; i < Math.min(x.length, y.length); i++) {
    if (Number.isFinite(x[i]) && Number.isFinite(y[i])) pairs.push([x[i], y[i]]);
  }
  if (pairs.length < 20) return { alpha: null, beta: null, r2: null, observations: pairs.length };
  const xs = pairs.map(p => p[0]);
  const ys = pairs.map(p => p[1]);
  const mx = mean(xs);
  const my = mean(ys);
  const varx = xs.reduce((s, v) => s + (v - mx) ** 2, 0);
  if (varx === 0) return { alpha: null, beta: null, r2: null, observations: pairs.length };
  const covxy = xs.reduce((s, v, i) => s + (v - mx) * (ys[i] - my), 0);
  const beta = covxy / varx;
  const alpha = my - beta * mx;
  const yhat = xs.map(v => alpha + beta * v);
  const ssTot = ys.reduce((s, v) => s + (v - my) ** 2, 0);
  const ssRes = ys.reduce((s, v, i) => s + (v - yhat[i]) ** 2, 0);
  const r2 = ssTot === 0 ? null : 1 - ssRes / ssTot;
  return { alpha, beta, r2, observations: pairs.length };
}

function maxDrawdown(rows) {
  let peak = -Infinity;
  let maxDd = 0;
  for (const row of rows) {
    const p = row.adjustedClose ?? row.close;
    if (!Number.isFinite(p)) continue;
    peak = Math.max(peak, p);
    const dd = (p - peak) / peak;
    if (Number.isFinite(dd)) maxDd = Math.min(maxDd, dd);
  }
  return maxDd;
}

function returnsByDate(rows) {
  const sorted = [...rows].sort((a, b) => a.date.localeCompare(b.date));
  const out = [];
  for (let i = 1; i < sorted.length; i++) {
    const p0 = sorted[i - 1].adjustedClose ?? sorted[i - 1].close;
    const p1 = sorted[i].adjustedClose ?? sorted[i].close;
    const r = Math.log(p1 / p0);
    if (Number.isFinite(r)) out.push({ date: sorted[i].date, r });
  }
  return out;
}

function matchReturns(stockRows, marketRows) {
  const s = returnsByDate(stockRows);
  const m = returnsByDate(marketRows);
  const mMap = new Map(m.map(x => [x.date, x.r]));
  const stock = [];
  const market = [];
  for (const row of s) {
    if (mMap.has(row.date)) {
      stock.push(row.r);
      market.push(mMap.get(row.date));
    }
  }
  return { stock, market, matchedDates: stock.length };
}

function returnsMap(rows) {
  return new Map(returnsByDate(rows).map(x => [x.date, x.r]));
}

function transpose(a) {
  return a[0].map((_, c) => a.map(r => r[c]));
}
function matMul(a, b) {
  const out = Array.from({ length: a.length }, () => Array(b[0].length).fill(0));
  for (let i = 0; i < a.length; i++) {
    for (let k = 0; k < b.length; k++) {
      for (let j = 0; j < b[0].length; j++) out[i][j] += a[i][k] * b[k][j];
    }
  }
  return out;
}
function inverse(matrix) {
  const n = matrix.length;
  const a = matrix.map((row, i) => [...row, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
  for (let i = 0; i < n; i++) {
    let pivot = i;
    for (let r = i + 1; r < n; r++) if (Math.abs(a[r][i]) > Math.abs(a[pivot][i])) pivot = r;
    if (Math.abs(a[pivot][i]) < 1e-12) return null;
    [a[i], a[pivot]] = [a[pivot], a[i]];
    const div = a[i][i];
    for (let c = 0; c < 2 * n; c++) a[i][c] /= div;
    for (let r = 0; r < n; r++) {
      if (r === i) continue;
      const f = a[r][i];
      for (let c = 0; c < 2 * n; c++) a[r][c] -= f * a[i][c];
    }
  }
  return a.map(row => row.slice(n));
}

function multiOls(dataset, factorNames) {
  const nObs = dataset.length;
  const k = factorNames.length + 1;
  if (nObs < Math.max(60, k * 12)) return { ok: false, reason: 'ข้อมูลไม่พอสำหรับ multi-factor regression', observations: nObs, factors: factorNames };
  const X = dataset.map(row => [1, ...factorNames.map(f => row[f])]);
  const y = dataset.map(row => [row.y]);
  const Xt = transpose(X);
  const XtX = matMul(Xt, X);
  // Tiny ridge term to avoid failure when factors are highly collinear.
  for (let i = 1; i < XtX.length; i++) XtX[i][i] += 1e-10;
  const inv = inverse(XtX);
  if (!inv) return { ok: false, reason: 'factor collinearity สูง ทำให้กลับ matrix ไม่ได้', observations: nObs, factors: factorNames };
  const betaMat = matMul(matMul(inv, Xt), y);
  const coeff = betaMat.map(r => r[0]);
  const yhat = X.map(row => row.reduce((s, v, i) => s + v * coeff[i], 0));
  const yVals = y.map(r => r[0]);
  const my = mean(yVals);
  const residuals = yVals.map((v, i) => v - yhat[i]);
  const ssTot = yVals.reduce((sum, v) => sum + (v - my) ** 2, 0);
  const ssRes = residuals.reduce((sum, v) => sum + v ** 2, 0);
  const r2 = ssTot === 0 ? null : 1 - ssRes / ssTot;
  const adjR2 = Number.isFinite(r2) ? 1 - (1 - r2) * (nObs - 1) / (nObs - k) : null;
  const sigma2 = ssRes / Math.max(1, nObs - k);
  const se = inv.map((row, i) => Math.sqrt(Math.max(0, sigma2 * row[i])));
  const residualStdevDaily = stdev(residuals);
  const coefficients = [{ name: 'Alpha', coefficient: coeff[0], stdError: se[0], tStat: se[0] ? coeff[0] / se[0] : null }]
    .concat(factorNames.map((name, i) => ({ name, coefficient: coeff[i + 1], stdError: se[i + 1], tStat: se[i + 1] ? coeff[i + 1] / se[i + 1] : null })));
  const fitted = dataset.slice(-180).map((row, i) => {
    const idx = dataset.length - Math.min(180, dataset.length) + i;
    return { date: row.date, actual: yVals[idx], fitted: yhat[idx], residual: residuals[idx] };
  });
  return { ok: true, observations: nObs, factors: factorNames, coefficients, r2, adjR2, residualStdevDaily, residualVolAnnual: Number.isFinite(residualStdevDaily) ? residualStdevDaily * Math.sqrt(252) : null, fitted };
}

function buildFactorDataset(stockRows, factorRowsByName) {
  const stockMap = returnsMap(stockRows);
  const factorMaps = Object.fromEntries(Object.entries(factorRowsByName).map(([name, rows]) => [name, returnsMap(rows || [])]));
  const factorNames = Object.keys(factorMaps).filter(name => factorMaps[name].size >= 120);
  const dataset = [];
  for (const [date, y] of stockMap.entries()) {
    const row = { date, y };
    let ok = true;
    for (const f of factorNames) {
      const val = factorMaps[f].get(date);
      if (!Number.isFinite(val)) { ok = false; break; }
      row[f] = val;
    }
    if (ok) dataset.push(row);
  }
  return { dataset: dataset.sort((a, b) => a.date.localeCompare(b.date)), factorNames };
}

function rollingBeta(stockRows, marketRows, windows = [30, 90, 180]) {
  const s = returnsByDate(stockRows);
  const m = returnsMap(marketRows);
  const pairs = s.map(x => ({ date: x.date, stock: x.r, market: m.get(x.date) })).filter(x => Number.isFinite(x.market));
  return pairs.map((row, i) => {
    const out = { date: row.date };
    for (const w of windows) {
      if (i + 1 >= w) {
        const slice = pairs.slice(i + 1 - w, i + 1);
        out[`beta${w}`] = ols(slice.map(x => x.market), slice.map(x => x.stock)).beta;
      } else out[`beta${w}`] = null;
    }
    return out;
  }).slice(-260);
}

function econometricsConfidence({ multi, matchedRows, priceRows, factorCount }) {
  let score = 0;
  const reasons = [];
  if (priceRows >= 500) { score += 2; reasons.push('มีราคามากกว่า 500 แถว'); }
  else if (priceRows >= 250) { score += 1; reasons.push('มีราคาประมาณ 1 ปีขึ้นไป'); }
  else reasons.push('ข้อมูลราคาสั้นเกินไป');

  if (matchedRows >= 400) { score += 2; reasons.push('วันที่ match benchmark เยอะ'); }
  else if (matchedRows >= 120) { score += 1; reasons.push('วันที่ match benchmark พอใช้'); }
  else reasons.push('วันที่ match benchmark น้อย');

  if (multi?.ok && Number.isFinite(multi.r2)) {
    if (multi.r2 >= 0.55) { score += 2; reasons.push('R² สูง โมเดลอธิบายการแกว่งได้ดีพอสมควร'); }
    else if (multi.r2 >= 0.25) { score += 1; reasons.push('R² ปานกลาง'); }
    else reasons.push('R² ต่ำ ความเสี่ยงอาจมาจากปัจจัยเฉพาะตัวหรือข่าว');
  } else reasons.push(multi?.reason || 'multi-factor model ไม่พร้อม');

  if (factorCount >= 3) { score += 1; reasons.push('มี factor หลายตัวให้เทียบ'); }
  else reasons.push('factor น้อย อธิบายความเสี่ยงได้จำกัด');

  const label = score >= 6 ? 'สูง' : score >= 3 ? 'ปานกลาง' : 'ต่ำ';
  return { score, maxScore: 7, label, reasons };
}

function interpretEconometrics({ single, multi }) {
  const notes = [];
  if (Number.isFinite(single?.beta)) {
    if (single.beta > 1.3) notes.push('หุ้นนี้ไวต่อตลาดสูง: ถ้า SPY แกว่ง หุ้นมักแกว่งแรงกว่า');
    else if (single.beta < 0.7) notes.push('Beta ต่ำกว่าตลาด: ราคาอาจนิ่งกว่าดัชนี แต่ยังต้องดู residual risk');
    else notes.push('Beta ใกล้ตลาด: ความเสี่ยงตลาดอยู่ระดับปกติ');
  }
  if (multi?.ok) {
    const residualVol = multi.residualVolAnnual;
    if (Number.isFinite(residualVol)) {
      if (residualVol > 0.35) notes.push('Residual volatility สูง: มีความเสี่ยงเฉพาะตัวบริษัท/sector มาก แม้ควบคุม factor แล้ว');
      else if (residualVol > 0.20) notes.push('Residual volatility ปานกลาง: ยังมีความเสี่ยงเฉพาะตัวพอควร');
      else notes.push('Residual volatility ต่ำ: การแกว่งส่วนใหญ่ถูกอธิบายด้วย factor ตลาดได้ค่อนข้างดี');
    }
    const top = multi.coefficients.filter(c => c.name !== 'Alpha' && Number.isFinite(c.coefficient)).sort((a, b) => Math.abs(b.coefficient) - Math.abs(a.coefficient))[0];
    if (top) notes.push(`Factor ที่สัมพันธ์แรงสุดในโมเดลคือ ${top.name} (coef ${top.coefficient.toFixed(2)})`);
  }
  return notes;
}



function trailingReturn(rows, tradingDays = 252) {
  const sorted = [...rows].sort((a, b) => a.date.localeCompare(b.date));
  if (sorted.length < Math.min(60, tradingDays / 2)) return null;
  const last = sorted.at(-1)?.adjustedClose ?? sorted.at(-1)?.close;
  const past = sorted[Math.max(0, sorted.length - 1 - tradingDays)]?.adjustedClose ?? sorted[Math.max(0, sorted.length - 1 - tradingDays)]?.close;
  if (!Number.isFinite(last) || !Number.isFinite(past) || past <= 0) return null;
  return last / past - 1;
}

function latestClose(rows) {
  const row = [...rows].sort((a, b) => a.date.localeCompare(b.date)).at(-1);
  const p = row?.adjustedClose ?? row?.close;
  return Number.isFinite(p) ? p : null;
}

function parseStooqCsv(csv) {
  const lines = String(csv || '').trim().split(/\r?\n/).filter(Boolean);
  if (lines.length <= 1 || /No data/i.test(csv)) return [];
  const header = lines[0].split(',').map(h => h.trim().toLowerCase());
  return lines.slice(1).map(line => {
    const cols = line.split(',');
    const obj = Object.fromEntries(header.map((h, i) => [h, cols[i]]));
    return {
      date: obj.date,
      open: Number(obj.open),
      high: Number(obj.high),
      low: Number(obj.low),
      close: Number(obj.close),
      adjustedClose: Number(obj.close),
      volume: Number(obj.volume)
    };
  }).filter(r => r.date && Number.isFinite(r.close));
}

async function getTickers() {
  if (tickerCache && Date.now() - tickerCacheAt < CACHE_MS) return tickerCache;
  try {
    const url = 'https://www.sec.gov/files/company_tickers_exchange.json';
    const { data } = await secClient.get(url);
    const fields = data.fields || [];
    const idx = name => fields.indexOf(name);
    const rows = (data.data || []).map(row => ({
      cik: padCik(row[idx('cik')]),
      name: row[idx('name')],
      symbol: String(row[idx('ticker')] || '').toUpperCase(),
      exchange: row[idx('exchange')]
    })).filter(x => x.symbol);
    tickerCache = rows;
    tickerCacheAt = Date.now();
    return rows;
  } catch (err) {
    tickerCache = FALLBACK_TICKERS;
    tickerCacheAt = Date.now();
    return FALLBACK_TICKERS;
  }
}

async function fetchStooq(symbol) {
  const s = `${symbol.toLowerCase()}.us`;
  const url = `https://stooq.com/q/d/l/?s=${encodeURIComponent(s)}&i=d`;
  const { data } = await normalClient.get(url, { responseType: 'text' });
  return parseStooqCsv(data);
}

function parseYahooChart(data) {
  const result = data?.chart?.result?.[0];
  const timestamps = result?.timestamp || [];
  const quote = result?.indicators?.quote?.[0] || {};
  const adj = result?.indicators?.adjclose?.[0]?.adjclose || [];
  return timestamps.map((t, i) => {
    const date = new Date(t * 1000).toISOString().slice(0, 10);
    return {
      date,
      open: n(quote.open?.[i]),
      high: n(quote.high?.[i]),
      low: n(quote.low?.[i]),
      close: n(quote.close?.[i]),
      adjustedClose: n(adj[i]) ?? n(quote.close?.[i]),
      volume: n(quote.volume?.[i])
    };
  }).filter(r => r.date && Number.isFinite(r.close));
}

async function fetchYahooDaily(symbol) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=5y&interval=1d&events=history&includeAdjustedClose=true`;
  const { data } = await normalClient.get(url, { responseType: 'json' });
  return parseYahooChart(data);
}



function parseYahooDividends(data) {
  const dividendsObj = data?.chart?.result?.[0]?.events?.dividends || {};
  return Object.values(dividendsObj).map(d => ({
    date: new Date(Number(d.date) * 1000).toISOString().slice(0, 10),
    amount: n(d.amount)
  })).filter(x => x.date && Number.isFinite(x.amount)).sort((a, b) => a.date.localeCompare(b.date));
}

async function fetchYahooDividends(symbol) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=5y&interval=1d&events=div%7Csplit&includeAdjustedClose=true`;
  const { data } = await normalClient.get(url, { responseType: 'json' });
  return parseYahooDividends(data);
}

async function fetchDividends(symbol, prices) {
  const attempts = [];
  try {
    const rows = await fetchYahooDividends(symbol);
    const latestDate = prices.at(-1)?.date || new Date().toISOString().slice(0, 10);
    const cutoff = new Date(latestDate);
    cutoff.setDate(cutoff.getDate() - 370);
    const cutoffStr = cutoff.toISOString().slice(0, 10);
    const ttmDividendPerShare = rows.filter(x => x.date >= cutoffStr && x.date <= latestDate).reduce((sum, x) => sum + x.amount, 0);
    const price = latestClose(prices);
    const dividendYield = Number.isFinite(price) && price > 0 && ttmDividendPerShare > 0 ? ttmDividendPerShare / price : 0;
    attempts.push({ provider: 'Yahoo Finance chart dividend events unofficial', rows: rows.length, ok: true });
    return { rows, ttmDividendPerShare, dividendYield, provider: 'Yahoo Finance chart dividend events unofficial', attempts };
  } catch (err) {
    attempts.push({ provider: 'Yahoo Finance chart dividend events unofficial', rows: 0, ok: false, error: err.message });
    return { rows: [], ttmDividendPerShare: null, dividendYield: null, provider: 'none', attempts };
  }
}

async function fetchPrices(symbol) {
  const attempts = [];
  try {
    const rows = await fetchStooq(symbol);
    attempts.push({ provider: 'Stooq daily CSV', rows: rows.length, ok: rows.length > 0 });
    if (rows.length) return { rows, provider: 'Stooq daily CSV', attempts };
  } catch (err) {
    attempts.push({ provider: 'Stooq daily CSV', rows: 0, ok: false, error: err.message });
  }
  try {
    const rows = await fetchYahooDaily(symbol);
    attempts.push({ provider: 'Yahoo Finance chart unofficial fallback', rows: rows.length, ok: rows.length > 0 });
    if (rows.length) return { rows, provider: 'Yahoo Finance chart unofficial fallback', attempts };
  } catch (err) {
    attempts.push({ provider: 'Yahoo Finance chart unofficial fallback', rows: 0, ok: false, error: err.message });
  }
  return { rows: [], provider: 'none', attempts };
}

async function fetchCompanyFacts(cik) {
  const url = `https://data.sec.gov/api/xbrl/companyfacts/CIK${padCik(cik)}.json`;
  const { data } = await secClient.get(url);
  return data;
}

const CONCEPTS = {
  revenue: [
    'RevenueFromContractWithCustomerExcludingAssessedTax',
    'RevenueFromContractWithCustomerIncludingAssessedTax',
    'Revenues',
    'SalesRevenueNet',
    'SalesRevenueGoodsNet',
    'SalesRevenueServicesNet'
  ],
  netIncome: ['NetIncomeLoss', 'ProfitLoss', 'IncomeLossFromContinuingOperationsIncludingPortionAttributableToNoncontrollingInterest'],
  assets: ['Assets', 'AssetsCurrent'],
  liabilities: ['Liabilities', 'LiabilitiesCurrent'],
  equity: [
    'StockholdersEquity',
    'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest',
    'PartnersCapital',
    'CommonStocksIncludingAdditionalPaidInCapital'
  ],
  operatingCashFlow: [
    'NetCashProvidedByUsedInOperatingActivities',
    'NetCashProvidedByUsedInOperatingActivitiesContinuingOperations',
    'NetCashProvidedByUsedInOperatingActivitiesContinuingAndDiscontinuedOperations'
  ],
  capex: [
    'PaymentsToAcquirePropertyPlantAndEquipment',
    'PaymentsToAcquireProductiveAssets',
    'PaymentsForProceedsFromProductiveAssets',
    'CapitalExpendituresIncurredButNotYetPaid'
  ],
  dividendsPaid: [
    'PaymentsOfDividends',
    'PaymentsOfDividendsCommonStock',
    'PaymentsOfDividendsAndDividendEquivalentsOnCommonStockAndRestrictedStockUnits',
    'PaymentsOfOrdinaryDividends',
    'DividendsPaid'
  ]
};
function getFactItems(facts, conceptNames) {
  const usgaap = facts?.facts?.['us-gaap'] || {};
  for (const concept of conceptNames) {
    const units = usgaap[concept]?.units || {};
    const items = units.USD || units.usd || [];
    if (items.length) {
      return { concept, label: usgaap[concept]?.label || concept, items };
    }
  }
  return { concept: null, label: null, items: [] };
}


function daysBetween(start, end) {
  if (!start || !end) return null;
  const a = new Date(start);
  const b = new Date(end);
  const d = Math.round((b - a) / 86400000);
  return Number.isFinite(d) ? d : null;
}

function fiscalRank(fp) {
  const order = { Q1: 1, Q2: 2, Q3: 3, Q4: 4, FY: 5 };
  return order[fp] || 0;
}

function isQuarterDuration(x) {
  const d = daysBetween(x.start, x.end);
  if (!Number.isFinite(d)) return false;
  // Prefer true quarter values. SEC also supplies many YTD cumulative facts, which can break quarter charts.
  return d >= 55 && d <= 115;
}

function isAnnualDuration(x) {
  const d = daysBetween(x.start, x.end);
  if (!Number.isFinite(d)) return false;
  return d >= 330 && d <= 390;
}

function cleanFactItems(items, instantLike = false) {
  const allowedForms = new Set(['10-K', '10-Q', '20-F', '40-F']);
  const cleaned = items
    .filter(x => allowedForms.has(x.form))
    .filter(x => x.fy && x.fp && x.end && Number.isFinite(Number(x.val)))
    .filter(x => instantLike ? true : x.start)
    .map(x => ({
      fy: x.fy,
      fp: x.fp,
      form: x.form,
      start: x.start || null,
      end: x.end,
      filed: x.filed,
      frame: x.frame || null,
      value: Number(x.val),
      durationDays: daysBetween(x.start, x.end),
      isQuarterDuration: instantLike ? false : isQuarterDuration(x),
      isAnnualDuration: instantLike ? false : isAnnualDuration(x)
    }))
    .sort((a, b) => `${b.end}-${b.filed}`.localeCompare(`${a.end}-${a.filed}`));

  // Deduplicate same fiscal period. Prefer frame-tagged facts, then proper quarter/annual duration, then newest filing.
  const best = new Map();
  for (const row of cleaned) {
    const key = `${row.fy}-${row.fp}-${row.end}`;
    const prev = best.get(key);
    if (!prev) { best.set(key, row); continue; }
    const score = r =>
      (r.frame ? 4 : 0) +
      (r.fp === 'FY' && r.isAnnualDuration ? 3 : 0) +
      (/^Q[1-4]$/.test(r.fp) && r.isQuarterDuration ? 3 : 0) +
      (r.form === '10-K' || r.form === '10-Q' ? 1 : 0);
    if (score(row) > score(prev) || (score(row) === score(prev) && String(row.filed).localeCompare(String(prev.filed)) > 0)) {
      best.set(key, row);
    }
  }
  return [...best.values()].sort((a, b) => `${b.end}-${b.filed}`.localeCompare(`${a.end}-${a.filed}`));
}

function keyOf(row) {
  return `${row.fy}-${row.fp}-${row.end}`;
}

function buildFinancials(facts) {
  const conceptsUsed = {};
  const raw = {};
  for (const [metric, concepts] of Object.entries(CONCEPTS)) {
    raw[metric] = getFactItems(facts, concepts);
    conceptsUsed[metric] = raw[metric].concept;
  }

  const revenue = cleanFactItems(raw.revenue.items).filter(x => x.fp === 'FY' ? x.isAnnualDuration : x.isQuarterDuration);
  const netIncome = cleanFactItems(raw.netIncome.items).filter(x => x.fp === 'FY' ? x.isAnnualDuration : x.isQuarterDuration);
  const assets = cleanFactItems(raw.assets.items, true);
  const liabilities = cleanFactItems(raw.liabilities.items, true);
  const equity = cleanFactItems(raw.equity.items, true);
  const operatingCashFlow = cleanFactItems(raw.operatingCashFlow.items).filter(x => x.fp === 'FY' ? x.isAnnualDuration : x.isQuarterDuration);
  const capex = cleanFactItems(raw.capex.items).filter(x => x.fp === 'FY' ? x.isAnnualDuration : x.isQuarterDuration);
  const dividendsPaid = cleanFactItems(raw.dividendsPaid.items).filter(x => x.fp === 'FY' ? x.isAnnualDuration : x.isQuarterDuration);

  const rowsMap = new Map();
  function addMetric(metric, rows) {
    for (const row of rows.slice(0, 120)) {
      const key = keyOf(row);
      if (!rowsMap.has(key)) rowsMap.set(key, { fy: row.fy, fp: row.fp, form: row.form, end: row.end, filed: row.filed, frame: row.frame, durationDays: row.durationDays });
      rowsMap.get(key)[metric] = metric === 'capex' ? Math.abs(row.value) : row.value;
      if (metric === 'capex' || metric === 'dividendsPaid') rowsMap.get(key)[metric] = Math.abs(row.value);
    }
  }
  addMetric('revenue', revenue);
  addMetric('netIncome', netIncome);
  addMetric('assets', assets);
  addMetric('liabilities', liabilities);
  addMetric('equity', equity);
  addMetric('operatingCashFlow', operatingCashFlow);
  addMetric('capex', capex);
  addMetric('dividendsPaid', dividendsPaid);

  let rows = [...rowsMap.values()]
    .map(r => ({ ...r, freeCashFlow: Number.isFinite(r.operatingCashFlow) && Number.isFinite(r.capex) ? r.operatingCashFlow - r.capex : null }))
    .sort((a, b) => b.end.localeCompare(a.end) || fiscalRank(b.fp) - fiscalRank(a.fp));

  // Remove rows that have almost no usable financial values; keeps graphs from showing empty bars.
  rows = rows.filter(r => ['revenue','netIncome','assets','liabilities','equity','operatingCashFlow','capex','freeCashFlow'].some(k => Number.isFinite(r[k])));

  const quarterly = rows.filter(r => /^Q[1-4]$/.test(r.fp)).slice(0, 16);
  const annual = rows.filter(r => r.fp === 'FY').slice(0, 8);
  const latestBalance = rows.find(r => Number.isFinite(r.assets) || Number.isFinite(r.liabilities) || Number.isFinite(r.equity)) || null;
  const latestIncome = rows.find(r => Number.isFinite(r.revenue) || Number.isFinite(r.netIncome)) || null;

  // Use latest 4 quarters if each metric has enough quarter data; otherwise fallback per metric to annual.
  const q4 = quarterly.slice(0, 4);
  const a1 = annual.slice(0, 1);
  function sumMetric(metric) {
    const qVals = q4.map(r => r[metric]).filter(Number.isFinite);
    if (qVals.length >= 3) return qVals.reduce((a, b) => a + b, 0);
    const aVal = a1.map(r => r[metric]).find(Number.isFinite);
    return Number.isFinite(aVal) ? aVal : null;
  }
  const ttm = {
    source: q4.length >= 4 ? 'latest quarters / annual fallback by metric' : 'latest annual fallback',
    revenue: sumMetric('revenue'),
    netIncome: sumMetric('netIncome'),
    operatingCashFlow: sumMetric('operatingCashFlow'),
    capex: sumMetric('capex'),
    dividendsPaid: sumMetric('dividendsPaid')
  };
  ttm.freeCashFlow = Number.isFinite(ttm.operatingCashFlow) && Number.isFinite(ttm.capex) ? ttm.operatingCashFlow - ttm.capex : null;

  const ratios = {
    netMargin: ttm.revenue ? ttm.netIncome / ttm.revenue : null,
    debtRatio: latestBalance?.assets ? latestBalance.liabilities / latestBalance.assets : null,
    roe: latestBalance?.equity ? ttm.netIncome / latestBalance.equity : null,
    fcfMargin: ttm.revenue ? ttm.freeCashFlow / ttm.revenue : null,
    dividendPayoutNetIncome: Number.isFinite(ttm.dividendsPaid) && ttm.dividendsPaid > 0 && Number.isFinite(ttm.netIncome) && ttm.netIncome !== 0 ? ttm.dividendsPaid / ttm.netIncome : null,
    dividendPayoutFcf: Number.isFinite(ttm.dividendsPaid) && ttm.dividendsPaid > 0 && Number.isFinite(ttm.freeCashFlow) && ttm.freeCashFlow !== 0 ? ttm.dividendsPaid / ttm.freeCashFlow : null
  };

  return {
    conceptsUsed,
    rows,
    quarterly,
    annual,
    latestBalance,
    latestIncome,
    ttm,
    ratios,
    counts: {
      revenue: revenue.length,
      netIncome: netIncome.length,
      assets: assets.length,
      liabilities: liabilities.length,
      equity: equity.length,
      operatingCashFlow: operatingCashFlow.length,
      capex: capex.length,
      dividendsPaid: dividendsPaid.length
    },
    notes: [
      'SEC XBRL บางบริษัทใช้ชื่อ concept ไม่เหมือนกัน ระบบจึงมี fallback หลายชื่อ',
      'สำหรับงบไตรมาส ระบบพยายามเลือกข้อมูลแบบ quarter duration ไม่ใช่ YTD สะสม',
      'ถ้ากราฟบางช่องว่าง แปลว่า SEC ไม่มี concept นั้นใน fiscal period นั้นหรือบริษัทจัด taxonomy ต่างกัน'
    ]
  };
}

function scoreShortRisk({ annualVol, var95, maxDd, beta }) {
  const parts = [];
  let score = 0;
  function add(name, value, pts, reason) { score += pts; parts.push({ name, value, points: pts, reason }); }
  if (!Number.isFinite(annualVol)) add('Volatility', null, 1, 'ข้อมูลไม่พอ');
  else if (annualVol < 0.25) add('Volatility', annualVol, 0, 'ผันผวนต่ำถึงปานกลาง');
  else if (annualVol < 0.45) add('Volatility', annualVol, 1, 'ผันผวนปานกลาง');
  else add('Volatility', annualVol, 2, 'ผันผวนสูง');

  if (!Number.isFinite(var95)) add('VaR 95%', null, 1, 'ข้อมูลไม่พอ');
  else if (var95 > -0.025) add('VaR 95%', var95, 0, 'downside รายวันไม่รุนแรง');
  else if (var95 > -0.045) add('VaR 95%', var95, 1, 'downside รายวันปานกลาง');
  else add('VaR 95%', var95, 2, 'downside รายวันสูง');

  if (!Number.isFinite(maxDd)) add('Max Drawdown', null, 1, 'ข้อมูลไม่พอ');
  else if (maxDd > -0.2) add('Max Drawdown', maxDd, 0, 'ย่อตัวไม่ลึกมากในช่วงข้อมูล');
  else if (maxDd > -0.4) add('Max Drawdown', maxDd, 1, 'เคยมีย่อตัวค่อนข้างลึก');
  else add('Max Drawdown', maxDd, 2, 'เคยย่อตัวลึกมาก');

  if (!Number.isFinite(beta)) add('Beta', null, 1, 'ข้อมูล benchmark ไม่พอ');
  else if (beta < 1.1) add('Beta', beta, 0, 'ไวต่อตลาดไม่สูงมาก');
  else if (beta < 1.6) add('Beta', beta, 1, 'ไวต่อตลาดปานกลางถึงสูง');
  else add('Beta', beta, 2, 'ไวต่อตลาดสูงมาก');

  const label = score <= 2 ? 'ต่ำ-ปานกลาง' : score <= 5 ? 'ปานกลาง' : 'สูง';
  return { score, maxScore: 8, label, parts };
}

function scoreLongRisk({ netMargin, debtRatio, roe, fcfMargin, dividendYield, dividendPayoutNetIncome, dividendPayoutFcf, oneYearReturn, maxDd }) {
  const parts = [];
  let score = 0;
  function add(name, value, pts, reason) { score += pts; parts.push({ name, value, points: pts, reason }); }

  if (!Number.isFinite(netMargin)) add('Net Margin', null, 1, 'ข้อมูลงบไม่พอ');
  else if (netMargin > 0.12) add('Net Margin', netMargin, 0, 'ทำกำไรดี');
  else if (netMargin > 0.03) add('Net Margin', netMargin, 1, 'ทำกำไรปานกลาง');
  else add('Net Margin', netMargin, 2, 'margin ต่ำหรือขาดทุน');

  if (!Number.isFinite(debtRatio)) add('Debt Ratio', null, 1, 'ข้อมูลงบดุลไม่พอ');
  else if (debtRatio < 0.6) add('Debt Ratio', debtRatio, 0, 'โครงสร้างหนี้ไม่สูงมาก');
  else if (debtRatio < 0.8) add('Debt Ratio', debtRatio, 1, 'หนี้ค่อนข้างสูง');
  else add('Debt Ratio', debtRatio, 2, 'หนี้สูงมากเทียบสินทรัพย์');

  if (!Number.isFinite(roe)) add('ROE', null, 1, 'ข้อมูล equity หรือกำไรไม่พอ');
  else if (roe > 0.12) add('ROE', roe, 0, 'ผลตอบแทนผู้ถือหุ้นดี');
  else if (roe > 0.03) add('ROE', roe, 1, 'ROE ปานกลาง');
  else add('ROE', roe, 2, 'ROE ต่ำหรือขาดทุน');

  if (!Number.isFinite(fcfMargin)) add('FCF Margin', null, 1, 'ข้อมูล cash flow ไม่พอ');
  else if (fcfMargin > 0.08) add('FCF Margin', fcfMargin, 0, 'กระแสเงินสดดี');
  else if (fcfMargin >= 0) add('FCF Margin', fcfMargin, 1, 'กระแสเงินสดบางแต่ยังบวก');
  else add('FCF Margin', fcfMargin, 2, 'FCF ติดลบ');

  // Dividend/yield-trap risk: high dividend yield is not automatically good. It can be high because price fell.
  if (!Number.isFinite(dividendYield) || dividendYield <= 0) add('Dividend Yield', dividendYield, 0, 'ไม่พบปันผล TTM หรือไม่ใช่หุ้นปันผล');
  else if (dividendYield <= 0.04) add('Dividend Yield', dividendYield, 0, 'yield ไม่สูงผิดปกติ');
  else if (dividendYield <= 0.08) add('Dividend Yield', dividendYield, 1, 'yield สูง ต้องตรวจ payout/กระแสเงินสด');
  else add('Dividend Yield', dividendYield, 2, 'yield สูงมาก อาจเป็นสัญญาณ yield trap');

  if (Number.isFinite(dividendYield) && dividendYield > 0) {
    if (!Number.isFinite(dividendPayoutFcf)) add('Dividend Payout/FCF', null, 1, 'มีปันผลแต่ข้อมูล FCF หรือ dividends paid ไม่พอ');
    else if (dividendPayoutFcf < 0) add('Dividend Payout/FCF', dividendPayoutFcf, 3, 'จ่ายปันผลทั้งที่ FCF ติดลบ');
    else if (dividendPayoutFcf <= 0.6) add('Dividend Payout/FCF', dividendPayoutFcf, 0, 'ปันผลยังถูกครอบคลุมด้วย FCF ดี');
    else if (dividendPayoutFcf <= 1.0) add('Dividend Payout/FCF', dividendPayoutFcf, 1, 'ใช้ FCF ไปกับปันผลค่อนข้างมาก');
    else add('Dividend Payout/FCF', dividendPayoutFcf, 2, 'ปันผลมากกว่า FCF เสี่ยงลดปันผล');

    if (Number.isFinite(dividendPayoutNetIncome)) {
      if (dividendPayoutNetIncome <= 0.75) add('Dividend Payout/NI', dividendPayoutNetIncome, 0, 'จ่ายปันผลไม่เกินกำไรสุทธิมาก');
      else if (dividendPayoutNetIncome <= 1.0) add('Dividend Payout/NI', dividendPayoutNetIncome, 1, 'payout ใกล้เต็มกำไร');
      else add('Dividend Payout/NI', dividendPayoutNetIncome, 2, 'จ่ายปันผลเกินกำไรสุทธิ');
    }
  }

  if (!Number.isFinite(oneYearReturn)) add('1Y Price Trend', null, 1, 'ข้อมูลราคา 1 ปีไม่พอ');
  else if (oneYearReturn > -0.10) add('1Y Price Trend', oneYearReturn, 0, 'ราคา 1 ปียังไม่เสียทรงมาก');
  else if (oneYearReturn > -0.30) add('1Y Price Trend', oneYearReturn, 1, 'ราคา 1 ปีอ่อนตัวชัดเจน');
  else add('1Y Price Trend', oneYearReturn, 2, 'ราคาลงแรงใน 1 ปี เสี่ยง value/yield trap');

  if (Number.isFinite(dividendYield) && dividendYield > 0.08 && Number.isFinite(maxDd) && maxDd < -0.35) {
    add('Yield Trap Combo', dividendYield, 2, 'yield สูงมากพร้อม drawdown ลึก: ต้องระวังว่าปันผลสูงเพราะราคาหุ้นร่วง');
  }

  const maxScore = 18;
  const label = score <= 4 ? 'ต่ำ-ปานกลาง' : score <= 8 ? 'ปานกลาง' : 'สูง';
  return { score, maxScore, label, parts };
}

function validateData({ prices, marketPrices, financials, priceSource, marketSource, dividends }) {
  const latestPriceDate = prices.at(-1)?.date || null;
  const latestMarketDate = marketPrices.at(-1)?.date || null;
  const latestStatementDate = financials.latestIncome?.end || financials.latestBalance?.end || null;
  const checks = [];
  checks.push({ name: `ราคาหุ้นจาก ${priceSource || 'price provider'}`, ok: prices.length >= 120, detail: `${prices.length} แถว, ล่าสุด ${latestPriceDate || '-'}` });
  checks.push({ name: `ราคา benchmark SPY จาก ${marketSource || 'price provider'}`, ok: marketPrices.length >= 120, detail: `${marketPrices.length} แถว, ล่าสุด ${latestMarketDate || '-'}` });
  checks.push({ name: 'วันที่ราคาหุ้นกับ SPY', ok: latestPriceDate && latestMarketDate && latestPriceDate === latestMarketDate, detail: `หุ้น ${latestPriceDate || '-'} / SPY ${latestMarketDate || '-'}` });
  checks.push({ name: 'งบรายไตรมาสที่ใช้กับกราฟ', ok: financials.quarterly.length >= 4, detail: `${financials.quarterly.length} แถว` });
  checks.push({ name: 'งบรายปี fallback', ok: financials.annual.length >= 1, detail: `${financials.annual.length} แถว` });
  checks.push({ name: 'Concept รายได้', ok: Boolean(financials.conceptsUsed.revenue), detail: financials.conceptsUsed.revenue || 'ไม่พบ' });
  checks.push({ name: 'Concept กำไรสุทธิ', ok: Boolean(financials.conceptsUsed.netIncome), detail: financials.conceptsUsed.netIncome || 'ไม่พบ' });
  checks.push({ name: 'Concept งบดุล', ok: Boolean(financials.conceptsUsed.assets && financials.conceptsUsed.liabilities), detail: `Assets=${financials.conceptsUsed.assets || '-'}, Liabilities=${financials.conceptsUsed.liabilities || '-'}` });
  checks.push({ name: 'Concept Cash Flow', ok: Boolean(financials.conceptsUsed.operatingCashFlow), detail: financials.conceptsUsed.operatingCashFlow || 'ไม่พบ' });
  checks.push({ name: 'วันที่งบล่าสุด', ok: Boolean(latestStatementDate), detail: latestStatementDate || '-' });
  checks.push({ name: 'Dividend events จาก Yahoo', ok: Boolean(dividends && dividends.rows && dividends.rows.length >= 0), detail: `${dividends?.rows?.length ?? 0} รายการ, TTM/share=${Number.isFinite(dividends?.ttmDividendPerShare) ? dividends.ttmDividendPerShare.toFixed(4) : '-'}` });
  checks.push({ name: 'Concept ปันผลจ่ายจาก SEC', ok: Boolean(financials.conceptsUsed.dividendsPaid), detail: financials.conceptsUsed.dividendsPaid || 'ไม่พบ' });
  return { checks, latestPriceDate, latestMarketDate, latestStatementDate };
}

app.get('/api/health', (req, res) => res.json({ ok: true, provider: ['SEC EDGAR', 'Stooq', 'Yahoo chart dividends fallback'], apiKeyRequired: false }));

app.get('/api/search', async (req, res) => {
  try {
    const q = String(req.query.q || '').trim().toLowerCase();
    const tickers = await getTickers();
    const results = tickers
      .filter(x => !q || x.symbol.toLowerCase().startsWith(q) || x.name.toLowerCase().includes(q))
      .sort((a, b) => {
        if (!q) return a.symbol.localeCompare(b.symbol);
        const as = a.symbol.toLowerCase() === q ? 0 : a.symbol.toLowerCase().startsWith(q) ? 1 : 2;
        const bs = b.symbol.toLowerCase() === q ? 0 : b.symbol.toLowerCase().startsWith(q) ? 1 : 2;
        return as - bs || a.symbol.localeCompare(b.symbol);
      })
      .slice(0, 25);
    res.json({ query: q, count: results.length, results, source: tickerCache === FALLBACK_TICKERS ? 'fallback list' : 'SEC company_tickers_exchange.json' });
  } catch (err) {
    res.status(500).json({ error: 'search_failed', message: err.message });
  }
});

app.get('/api/analyze/:symbol', async (req, res) => {
  const symbol = String(req.params.symbol || '').trim().toUpperCase();
  try {
    const tickers = await getTickers();
    const company = tickers.find(x => x.symbol === symbol);
    if (!company) return res.status(404).json({ error: 'symbol_not_found', message: `ไม่พบ ticker ${symbol}` });

    const factorSymbols = { QQQ: 'Nasdaq 100 / growth proxy', IWM: 'Small-cap proxy', TLT: 'Long-term bonds / rate sensitivity', USO: 'Oil proxy' };
    const [priceSettled, marketSettled, factsSettled, factorSettled] = await Promise.allSettled([
      fetchPrices(symbol),
      fetchPrices('SPY'),
      fetchCompanyFacts(company.cik),
      Promise.allSettled(Object.keys(factorSymbols).map(sym => fetchPrices(sym).then(value => ({ sym, value }))))
    ]);

    const priceResult = priceSettled.status === 'fulfilled' ? priceSettled.value : { rows: [], provider: 'none', attempts: [{ provider: 'all price providers', rows: 0, ok: false, error: priceSettled.reason?.message || String(priceSettled.reason) }] };
    const marketResult = marketSettled.status === 'fulfilled' ? marketSettled.value : { rows: [], provider: 'none', attempts: [{ provider: 'all benchmark providers', rows: 0, ok: false, error: marketSettled.reason?.message || String(marketSettled.reason) }] };
    const facts = factsSettled.status === 'fulfilled' ? factsSettled.value : { facts: { 'us-gaap': {} }, secFetchError: factsSettled.reason?.message || String(factsSettled.reason) };
    const factorResults = {};
    const factorFetchAttempts = [];
    if (factorSettled.status === 'fulfilled') {
      for (const item of factorSettled.value) {
        if (item.status === 'fulfilled') {
          factorResults[item.value.sym] = item.value.value.rows || [];
          factorFetchAttempts.push({ symbol: item.value.sym, provider: item.value.value.provider, rows: item.value.value.rows?.length || 0, ok: (item.value.value.rows?.length || 0) > 0, attempts: item.value.value.attempts });
        }
      }
    }

    const prices = priceResult.rows;
    const marketPrices = marketResult.rows;

    const dividends = await fetchDividends(symbol, prices);

    const financials = buildFinancials(facts);
    if (facts.secFetchError) {
      financials.secFetchError = facts.secFetchError;
      financials.notes = [`SEC companyfacts ดึงไม่สำเร็จ: ${facts.secFetchError}`, ...(financials.notes || [])];
    }
    const stockReturns = returnsByDate(prices).map(x => x.r);
    const annualVol = stdev(stockReturns) ? stdev(stockReturns) * Math.sqrt(252) : null;
    const avgDaily = mean(stockReturns);
    const annualReturn = Number.isFinite(avgDaily) ? avgDaily * 252 : null;
    const var95 = percentile(stockReturns, 0.05);
    const maxDd = maxDrawdown(prices);
    const oneYearReturn = trailingReturn(prices, 252);
    const matched = matchReturns(prices, marketPrices);
    const reg = ols(matched.market, matched.stock);
    const factorRowsByName = { SPY: marketPrices, ...factorResults };
    const factorDataset = buildFactorDataset(prices, factorRowsByName);
    const multiFactor = multiOls(factorDataset.dataset, factorDataset.factorNames);
    const rolling = rollingBeta(prices, marketPrices);
    const confidence = econometricsConfidence({ multi: multiFactor, matchedRows: matched.matchedDates, priceRows: prices.length, factorCount: factorDataset.factorNames.length });
    const econometrics = {
      singleFactor: { alpha: reg.alpha, beta: reg.beta, r2: reg.r2, observations: reg.observations, benchmark: 'SPY' },
      multiFactor,
      rollingBeta: rolling,
      factorCoverage: Object.fromEntries(Object.entries(factorRowsByName).map(([k, rows]) => [k, { rows: rows?.length || 0 }])),
      modelConfidence: confidence,
      interpretation: interpretEconometrics({ single: reg, multi: multiFactor })
    };
    financials.ratios.dividendYield = dividends.dividendYield;
    financials.ratios.dividendPayoutNetIncome = financials.ratios.dividendPayoutNetIncome;
    financials.ratios.dividendPayoutFcf = financials.ratios.dividendPayoutFcf;
    const shortRisk = scoreShortRisk({ annualVol, var95, maxDd, beta: reg.beta });
    const longRisk = scoreLongRisk({ ...financials.ratios, oneYearReturn, maxDd });
    const validation = validateData({ prices, marketPrices, financials, priceSource: priceResult.provider, marketSource: marketResult.provider, dividends });

    const response = {
      symbol,
      company,
      providers: {
        search: 'SEC company_tickers_exchange.json',
        financials: facts.secFetchError ? `SEC EDGAR companyfacts XBRL ไม่สำเร็จ: ${facts.secFetchError}` : 'SEC EDGAR companyfacts XBRL',
        prices: priceResult.provider,
        benchmark: `SPY from ${marketResult.provider}`,
        dividends: dividends.provider,
        econometrics: 'Single-factor OLS + multi-factor OLS + rolling beta (free ETF proxies)'
      },
      fetchedAt: new Date().toISOString(),
      prices,
      priceFetchAttempts: priceResult.attempts,
      marketPrices: marketPrices.slice(-260),
      marketFetchAttempts: marketResult.attempts,
      dividends,
      dividendFetchAttempts: dividends.attempts,
      factorFetchAttempts,
      econometrics,
      financials,
      metrics: {
        priceRows: prices.length,
        stockReturnRows: stockReturns.length,
        matchedBenchmarkRows: matched.matchedDates,
        annualVol,
        annualReturn,
        var95,
        maxDrawdown: maxDd,
        alpha: reg.alpha,
        beta: reg.beta,
        r2: reg.r2,
        regressionObservations: reg.observations,
        oneYearReturn,
        dividendYield: dividends.dividendYield,
        ttmDividendPerShare: dividends.ttmDividendPerShare,
        ...financials.ratios,
        ...financials.ttm
      },
      risk: { short: shortRisk, long: longRisk },
      validation
    };
    res.json(response);
  } catch (err) {
    res.status(500).json({ error: 'analyze_failed', message: err.message, symbol });
  }
});

app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
